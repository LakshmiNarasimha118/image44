import express, { Request, Response } from 'express';//importing express
import path from 'path';//importing path
import fsp from 'fs/promises';//importing filesystem 

import { imageCrop } from './routes/index';
import { AnySrvRecord } from 'dns';

const app = express();
const port = 5000;

app.get('/', async(req: Request, res: Response):Promise<void> => {
  res.send('<h1>I am running at port 5000</h1>');//sending the response I am running at port 5000
});

app.use('/images', async (req: Request, res: Response):Promise<void>=>{
	const imageFolder = `${path.resolve(//adding image path to imageFolder 
		__dirname,
		`./../images/fullImages`,
	  )}`;
	const files : string[] | any = await fsp
      .readdir(imageFolder)
      .catch(() => {
        res.send('Error reading images');
        return;
    });
    if (!files) return;//when file not found return nothing

	let myImages = ''

	files.map((file: string, index: number): void => {
		myImages = myImages+ `<p>${index + 1} - ${file}</p>`;
	});

	res.send(`${myImages}`);
	return
});

app.use('/crop-image', imageCrop);


app.listen(port, (): void =>{//it is listening to port 5000.
  console.log(`Listening at: ${port}`);
});

export default app;

