import supertest from "supertest";
import app from "../index";
import sizeOf from "image-size";
import fs from "fs/promises";
import path from "path"; //importing the path.
import { Stats } from "fs"; //importing ths fs.
import imageReSize from "../helper/imageCropper";

describe("GET /",async ()=> {
  //we are calling the get function here.
    it ("responds with 200", async()=>{
      const response = await supertest(app).get("/")
      expect(response.status).toBe(200)
    })
    
});

describe("GET /api/images", async () => {
  it("404 if called correctly but does not exist the image", async() => {
      const response = await supertest(app).get("/crop-image?name=test&height=100&width=100")
      expect(response.status).toBe(200);
  });
  it("responds with 200 if called correctly and image exist", async() => {
    const response = await supertest(app).get("/crop-image?name=santamonica&height=100&width=100")
    expect(response.status).toBe(200);
  });
  /*it("created a version of new image", async() => {
    await supertest(app).get("/crop-image?name=santamonica&height=100&width=100")
      .then(() => {
        fs.stat(
          path.resolve(
            __dirname,
            "../../../images/newImages/santamonica-100x100.jpg"
          )
        ).then((fileStat: Stats) => expect(fileStat).not.toBeNull());
      });
  });*/

  /*const response1 = await supertest(app).get("/")
  expect(response1.status).toBe(200);
  const response2 = await supertest(app).get("/")
  expect(response2.status).toBe(200);*/

  /*it("created a thumb version of the image with the correct height and width",createdFunc);
  
  async function createdFunc(){
    supertest(app)
      .get("/crop-image?name=palmtunnel&height=100&width=150")
      .then(() => {
        const dimensions = sizeOf(
          path.resolve(__dirname, "../../../images/newImages/fjord-100x150.jpg")
        );
        expect(dimensions.height).toEqual(100);
        expect(dimensions.width).toEqual(150);
      });
  };*/
});

const newImagePath = path.resolve(
  __dirname,
  "./../../images/newImages/santamonica.jpg"
);

const fullImagePath = path.resolve(
  __dirname,
  "./../../images/fullImages/santamonica.jpg"
);

/*describe("This is an image resize function", describefunction);

async function describefunction() {
  it("If something went wrong promise will reject", async () => {
    await expectAsync(
      imageReSize(150, 200, fullImagePath, newImagePath)
    ).toBeRejected();
  });
}*/
