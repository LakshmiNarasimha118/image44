import express, { Response, Request } from "express"; //importing express.
import path from "path"; //importing path
import fs from "fs"; //importing file system.

import imageCropper from "../helper/imageCropper";

const router = express.Router();

export const imageCrop = router.use(
  "/",
  async (req: Request, res: Response): Promise<void> => {
    const query = req.query || {};

    if (!query.name || !query.width || !query.height) {
      res.send('<h3 color="red">Please provide valid query</h3>');
      return;
    }

    const imagePath = `${path.resolve(
      __dirname,
      `./../../images/fullImages/${query.name}.jpg`
    )}`;

    const newPath = `${path.resolve(
      __dirname,
      `./../../images/newImages/${query.name}-${query.height}x${query.width}.jpg`
    )}`;

    if (fs.existsSync(newPath)) {
      res.status(200).sendFile(newPath);
    } else if (
      fs.existsSync(imagePath) &&
      Number(query.height) > 0 &&
      Number(query.width) > 0
    ) {
      try {
        await imageCropper(
          Number(query.width),
          Number(query.height),
          imagePath,
          newPath
        ).then(() => {
          res.status(200).sendFile(newPath);
        });
      } catch (error) {
        res.send("error" + error);
      }
    } else {
      res.send("<h2>Something went wrong</h2>");
    }
  }
);
